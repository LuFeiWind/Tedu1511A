//
//  ViewController.m
//  Day28_AutoLayout
//
//  Created by tarena on 16/3/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIView *redView = [UIView new];
    redView.backgroundColor = [UIColor redColor];
    [self.view addSubview:redView];
    //右20 上20 宽度80 高度40
    //因为AutoLayout是由AutoResizing演变而来的. 自带了左上两条布局线, 我们需要先去掉.
    //转化Autoresizing到约束
    redView.translatesAutoresizingMaskIntoConstraints = NO;
    //距离上边缘20像素的约束
    //view1.attr1 = view2.attr2 * multiplier + constant
    //use nil and NSLayoutAttributeNotAnAttribute
    //红色视图.上=self.view.上 * 1.0 + 20
    NSLayoutConstraint *topC = [NSLayoutConstraint constraintWithItem:redView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1.0 constant:20];
    //右边20像素
    //红色视图.右=self.view.右*1.0 - 20
    NSLayoutConstraint *rightC = [NSLayoutConstraint constraintWithItem:redView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1.0 constant:-20];
    //宽度等于80
    NSLayoutConstraint *widthC = [NSLayoutConstraint constraintWithItem:redView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:80];
    //高度等于40, 自己写
    NSLayoutConstraint *heightC = [NSLayoutConstraint constraintWithItem:redView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:40];
    [self.view addConstraints:@[topC, rightC, heightC, widthC]];
    
    //苹果提供了VFL语法,专门用于添加约束
    UIView *v1 = [UIView new];
    v1.backgroundColor = [UIColor blueColor];
    [self.view addSubview:v1];
    UIView *v2 = [UIView new];
    v2.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:v2];
    UIView *v3 = [UIView new];
    [self.view addSubview:v3];
    v3.backgroundColor = [UIColor orangeColor];
    v1.translatesAutoresizingMaskIntoConstraints=NO;
    v2.translatesAutoresizingMaskIntoConstraints=NO;
    v3.translatesAutoresizingMaskIntoConstraints=NO;
    /*
     | 代表父视图边缘, 按照左右来区分是左右边缘
     V:| 代表上下父视图边缘
     -:代表距离8
     -数字-: 距离是数字大小, 例如-20- 表示距离20
     [视图]: []中放视图
     视图1(视图2):视图1 和2 的宽度相等
     视图1(==100): 视图1的宽度等于100
     */
    NSString *hVFL = @"|-left-[v1]-space-[v2(v1)]-space-[v3(v1)]-right-|";
    NSDictionary *metricDic = @{@"left":@20, @"space": @10, @"top":@20, @"right":@20};
    //@{@"v1":v1, @"v2":v2, @"v3":v3}
    NSDictionary *viewsDic = NSDictionaryOfVariableBindings(v1, v2, v3);
    //通过vfl语法生成约束
    NSArray *c1 = [NSLayoutConstraint constraintsWithVisualFormat:hVFL options:NSLayoutFormatAlignAllTop|NSLayoutFormatAlignAllBottom metrics:metricDic views:viewsDic];
    [self.view addConstraints:c1];
    
    NSString *vVFL = @"V:|-top-[v1(==100)]";
    NSArray *c2 = [NSLayoutConstraint constraintsWithVisualFormat:vVFL options:0 metrics:metricDic views:viewsDic];
    [self.view addConstraints:c2];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
